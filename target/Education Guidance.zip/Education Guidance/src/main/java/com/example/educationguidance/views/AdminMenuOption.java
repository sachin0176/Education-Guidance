package com.example.educationguidance.views;

public enum AdminMenuOption {

    ALL_USER, LATEST_USER, UPDATE,FEEDBACK
}
