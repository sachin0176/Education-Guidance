package com.example.educationguidance.views;

public enum AccountType {

    ADMIN, USER
}
