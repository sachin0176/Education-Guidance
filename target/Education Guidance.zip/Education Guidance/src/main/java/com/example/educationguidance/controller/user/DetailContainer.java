package com.example.educationguidance.controller.user;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import java.net.URL;
import java.util.ResourceBundle;

public class DetailContainer implements Initializable{
    public Label date_lbl;
    public  TextArea text_area;
    public  Label grade_lbl;
    public Button back_btn;




    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


}
